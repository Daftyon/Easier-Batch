from setuptools import setup, find_packages

setup(
    name='easier-batch',
    version='0.2',
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
    ],
)
